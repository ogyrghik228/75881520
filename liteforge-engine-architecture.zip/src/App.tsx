import { useState, useEffect, useRef, useCallback } from 'react';
import { LiteForgeEngine, EngineStats } from './engine/LiteForgeEngine';
import { MATERIALS, MaterialProperties, MaterialCategory, MaterialState } from './engine/MaterialDatabase';

const CATEGORY_LABELS: Record<MaterialCategory, string> = {
  [MaterialCategory.METAL]: '🔩 Металлы',
  [MaterialCategory.WOOD]: '🪵 Дерево',
  [MaterialCategory.STONE]: '🪨 Камень',
  [MaterialCategory.PLASTIC]: '🧴 Пластик',
  [MaterialCategory.GLASS]: '🪟 Стекло',
  [MaterialCategory.ORGANIC]: '🌿 Органика',
  [MaterialCategory.CHEMICAL]: '🧪 Химия',
  [MaterialCategory.FABRIC]: '🧵 Ткань',
  [MaterialCategory.CERAMIC]: '🏺 Керамика',
  [MaterialCategory.COMPOSITE]: '🔧 Композиты',
};

const STATE_LABELS: Record<MaterialState, string> = {
  [MaterialState.SOLID]: '🧊 Твердое',
  [MaterialState.LIQUID]: '💧 Жидкость',
  [MaterialState.GAS]: '💨 Газ',
  [MaterialState.PLASMA]: '⚡ Плазма',
};

function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<LiteForgeEngine | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [stats, setStats] = useState<EngineStats>({ fps: 0, bodies: 0, particles: 0, fragments: 0, deviceTier: 'medium' });
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialProperties>(MATERIALS[0]);
  const [brushSize, setBrushSize] = useState(30);
  const [showMaterialPanel, setShowMaterialPanel] = useState(true);
  const [filterCategory, setFilterCategory] = useState<MaterialCategory | 'all'>('all');
  const [isMouseDown, setIsMouseDown] = useState(false);
  const lastSpawnTime = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set initial size
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      if (engineRef.current) {
        engineRef.current.resize(canvas.width, canvas.height);
      }
    };

    window.addEventListener('resize', resize);

    try {
      const engine = new LiteForgeEngine(canvas);
      engineRef.current = engine;
      engine.start();
      setIsReady(true);
    } catch (error) {
      console.error('Engine initialization failed:', error);
    }

    // Stats update interval
    const statsInterval = setInterval(() => {
      if (engineRef.current) {
        setStats(engineRef.current.getStats());
      }
    }, 100);

    return () => {
      window.removeEventListener('resize', resize);
      clearInterval(statsInterval);
      if (engineRef.current) {
        engineRef.current.stop();
      }
    };
  }, []);

  const spawnBody = useCallback((x: number, y: number) => {
    const now = performance.now();
    if (now - lastSpawnTime.current < 50) return; // Throttle
    lastSpawnTime.current = now;

    if (engineRef.current) {
      const variation = brushSize * 0.2;
      const radius = brushSize + (Math.random() - 0.5) * variation;
      engineRef.current.addBody(x, y, radius, selectedMaterial);
      
      // Spawn effects
      if (selectedMaterial.state === MaterialState.LIQUID) {
        engineRef.current.emitParticles(x, y, 5, 'water');
      } else if (selectedMaterial.emissiveStrength > 0) {
        engineRef.current.emitParticles(x, y, 3, 'spark');
      }
    }
  }, [selectedMaterial, brushSize]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.target !== canvasRef.current) return;
    setIsMouseDown(true);
    spawnBody(e.clientX, e.clientY);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDown) return;
    spawnBody(e.clientX, e.clientY);
  };

  const handleMouseUp = () => {
    setIsMouseDown(false);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.target !== canvasRef.current) return;
    e.preventDefault();
    const touch = e.touches[0];
    spawnBody(touch.clientX, touch.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    e.preventDefault();
    const touch = e.touches[0];
    spawnBody(touch.clientX, touch.clientY);
  };

  const clearAll = () => {
    engineRef.current?.clear();
  };

  const filteredMaterials = filterCategory === 'all' 
    ? MATERIALS 
    : MATERIALS.filter(m => m.category === filterCategory);

  const getColorStyle = (color: [number, number, number], metallic: number, emissive: [number, number, number], emissiveStrength: number) => {
    const r = Math.round(color[0] * 255);
    const g = Math.round(color[1] * 255);
    const b = Math.round(color[2] * 255);
    
    if (emissiveStrength > 0) {
      const er = Math.round(emissive[0] * 255);
      const eg = Math.round(emissive[1] * 255);
      const eb = Math.round(emissive[2] * 255);
      return {
        background: `radial-gradient(circle, rgba(${er},${eg},${eb},0.8) 0%, rgb(${r},${g},${b}) 100%)`,
        boxShadow: `0 0 10px rgba(${er},${eg},${eb},0.8)`
      };
    }
    
    if (metallic > 0.5) {
      return {
        background: `linear-gradient(135deg, rgba(${r+60},${g+60},${b+60},1) 0%, rgb(${r},${g},${b}) 50%, rgba(${Math.floor(r*0.6)},${Math.floor(g*0.6)},${Math.floor(b*0.6)},1) 100%)`
      };
    }
    
    return { background: `rgb(${r},${g},${b})` };
  };

  return (
    <div 
      className="relative w-full h-screen overflow-hidden bg-slate-900"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 touch-none"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
      />

      {/* Stats Panel */}
      <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-sm rounded-xl p-4 text-white font-mono text-sm z-10">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-2xl">🎮</span>
          <span className="font-bold text-lg">LiteForge Engine</span>
        </div>
        {isReady ? (
          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
            <span className="text-gray-400">FPS:</span>
            <span className={stats.fps < 30 ? 'text-red-400' : stats.fps < 50 ? 'text-yellow-400' : 'text-green-400'}>
              {stats.fps}
            </span>
            <span className="text-gray-400">Объекты:</span>
            <span className="text-blue-400">{stats.bodies}</span>
            <span className="text-gray-400">Частицы:</span>
            <span className="text-purple-400">{stats.particles}</span>
            <span className="text-gray-400">Осколки:</span>
            <span className="text-orange-400">{stats.fragments}</span>
            <span className="text-gray-400">Устройство:</span>
            <span className={
              stats.deviceTier === 'high' ? 'text-green-400' :
              stats.deviceTier === 'medium' ? 'text-yellow-400' : 'text-red-400'
            }>
              {stats.deviceTier === 'high' ? '🚀 High' :
               stats.deviceTier === 'medium' ? '⚡ Medium' : '🔋 Low'}
            </span>
          </div>
        ) : (
          <div className="text-yellow-400">Инициализация...</div>
        )}
      </div>

      {/* Controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
        <button
          onClick={() => setShowMaterialPanel(!showMaterialPanel)}
          className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2"
        >
          <span>🎨</span>
          <span>Материалы</span>
        </button>
        <button
          onClick={clearAll}
          className="bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2"
        >
          <span>🗑️</span>
          <span>Очистить</span>
        </button>
      </div>

      {/* Brush Size */}
      <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-sm rounded-xl p-4 text-white z-10">
        <div className="flex items-center gap-4">
          <span className="text-sm text-gray-400">Размер кисти:</span>
          <input
            type="range"
            min="10"
            max="80"
            value={brushSize}
            onChange={(e) => setBrushSize(Number(e.target.value))}
            className="w-32 accent-indigo-500"
          />
          <span className="w-8 text-center">{brushSize}</span>
        </div>
      </div>

      {/* Current Material */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/60 backdrop-blur-sm rounded-xl p-3 text-white flex items-center gap-3 z-10">
        <div
          className="w-12 h-12 rounded-full border-2 border-white/30"
          style={getColorStyle(selectedMaterial.baseColor, selectedMaterial.metallic, selectedMaterial.emissive, selectedMaterial.emissiveStrength)}
        />
        <div>
          <div className="font-medium">{selectedMaterial.name}</div>
          <div className="text-xs text-gray-400 flex gap-2">
            <span>{STATE_LABELS[selectedMaterial.state]}</span>
            <span>•</span>
            <span>{selectedMaterial.density} кг/м³</span>
          </div>
        </div>
      </div>

      {/* Instructions */}
      <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur-sm rounded-xl p-3 text-white text-sm text-right z-10">
        <div className="text-gray-400">Клик/тап для создания объектов</div>
        <div className="text-gray-400">Физика + разрушение материалов</div>
      </div>

      {/* Material Panel */}
      {showMaterialPanel && (
        <div className="absolute top-20 right-4 w-80 max-h-[70vh] bg-black/80 backdrop-blur-md rounded-xl overflow-hidden flex flex-col z-20">
          <div className="p-3 border-b border-white/10">
            <div className="text-white font-medium mb-2">Выберите материал</div>
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value as MaterialCategory | 'all')}
              className="w-full bg-white/10 text-white rounded-lg px-3 py-2 text-sm outline-none"
            >
              <option value="all">Все категории</option>
              {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2">
            <div className="grid grid-cols-2 gap-2">
              {filteredMaterials.map((material) => (
                <button
                  key={material.id}
                  onClick={() => setSelectedMaterial(material)}
                  className={`p-2 rounded-lg text-left transition-all ${
                    selectedMaterial.id === material.id
                      ? 'bg-indigo-600 ring-2 ring-indigo-400'
                      : 'bg-white/10 hover:bg-white/20'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className="w-8 h-8 rounded-full border border-white/20 flex-shrink-0"
                      style={getColorStyle(material.baseColor, material.metallic, material.emissive, material.emissiveStrength)}
                    />
                    <div className="min-w-0">
                      <div className="text-white text-xs font-medium truncate">
                        {material.name}
                      </div>
                      <div className="text-gray-400 text-xs">
                        {STATE_LABELS[material.state].split(' ')[0]}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Material Properties */}
          <div className="p-3 border-t border-white/10 bg-white/5">
            <div className="text-white text-xs font-medium mb-2">{selectedMaterial.name}</div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
              <div className="text-gray-400">Плотность</div>
              <div className="text-white">{selectedMaterial.density} кг/м³</div>
              <div className="text-gray-400">Твердость</div>
              <div className="text-white">{selectedMaterial.hardness} / 10</div>
              <div className="text-gray-400">Хрупкость</div>
              <div className="text-white">{Math.round(selectedMaterial.brittleness * 100)}%</div>
              <div className="text-gray-400">Упругость</div>
              <div className="text-white">{Math.round(selectedMaterial.elasticity * 100)}%</div>
              <div className="text-gray-400">Т плавления</div>
              <div className="text-white">{selectedMaterial.meltingPoint < 9999 ? `${selectedMaterial.meltingPoint}°C` : '—'}</div>
              <div className="text-gray-400">Металл</div>
              <div className="text-white">{selectedMaterial.metallic > 0.5 ? '✓' : '✗'}</div>
            </div>
            <div className="flex flex-wrap gap-1 mt-2">
              {selectedMaterial.canShatter && (
                <span className="px-2 py-0.5 bg-red-500/30 text-red-300 rounded text-xs">💥 Бьется</span>
              )}
              {selectedMaterial.canDeform && (
                <span className="px-2 py-0.5 bg-yellow-500/30 text-yellow-300 rounded text-xs">🔨 Деформируется</span>
              )}
              {selectedMaterial.canMelt && (
                <span className="px-2 py-0.5 bg-orange-500/30 text-orange-300 rounded text-xs">🔥 Плавится</span>
              )}
              {selectedMaterial.canBurn && (
                <span className="px-2 py-0.5 bg-red-500/30 text-red-300 rounded text-xs">🔥 Горит</span>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
