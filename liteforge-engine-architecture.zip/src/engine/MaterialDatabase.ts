export enum MaterialState {
  SOLID = 'solid',
  LIQUID = 'liquid',
  GAS = 'gas',
  PLASMA = 'plasma'
}

export enum MaterialCategory {
  METAL = 'metal',
  WOOD = 'wood',
  STONE = 'stone',
  PLASTIC = 'plastic',
  GLASS = 'glass',
  ORGANIC = 'organic',
  CHEMICAL = 'chemical',
  FABRIC = 'fabric',
  CERAMIC = 'ceramic',
  COMPOSITE = 'composite'
}

export interface MaterialProperties {
  id: number;
  name: string;
  category: MaterialCategory;
  state: MaterialState;
  density: number;
  hardness: number;
  brittleness: number;
  elasticity: number;
  friction: number;
  meltingPoint: number;
  boilingPoint: number;
  thermalConductivity: number;
  baseColor: [number, number, number];
  roughness: number;
  metallic: number;
  transparency: number;
  reflectivity: number;
  emissive: [number, number, number];
  emissiveStrength: number;
  canShatter: boolean;
  canDeform: boolean;
  canMelt: boolean;
  canBurn: boolean;
  soundType: string;
}

export const MATERIALS: MaterialProperties[] = [
  // METALS
  {
    id: 1, name: 'Сталь углеродистая', category: MaterialCategory.METAL, state: MaterialState.SOLID,
    density: 7850, hardness: 5.5, brittleness: 0.3, elasticity: 0.2, friction: 0.74,
    meltingPoint: 1370, boilingPoint: 2750, thermalConductivity: 50.2,
    baseColor: [0.65, 0.65, 0.70], roughness: 0.4, metallic: 1.0, transparency: 0, reflectivity: 0.75,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: false, canDeform: true, canMelt: true, canBurn: false, soundType: 'metal_impact'
  },
  {
    id: 2, name: 'Алюминий', category: MaterialCategory.METAL, state: MaterialState.SOLID,
    density: 2700, hardness: 2.75, brittleness: 0.2, elasticity: 0.3, friction: 0.61,
    meltingPoint: 660, boilingPoint: 2519, thermalConductivity: 237,
    baseColor: [0.91, 0.92, 0.93], roughness: 0.3, metallic: 1.0, transparency: 0, reflectivity: 0.85,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: false, canDeform: true, canMelt: true, canBurn: true, soundType: 'metal_light'
  },
  {
    id: 3, name: 'Медь', category: MaterialCategory.METAL, state: MaterialState.SOLID,
    density: 8960, hardness: 3.0, brittleness: 0.15, elasticity: 0.35, friction: 0.53,
    meltingPoint: 1085, boilingPoint: 2562, thermalConductivity: 401,
    baseColor: [0.95, 0.64, 0.54], roughness: 0.25, metallic: 1.0, transparency: 0, reflectivity: 0.90,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: false, canDeform: true, canMelt: true, canBurn: false, soundType: 'metal_resonant'
  },
  {
    id: 4, name: 'Золото', category: MaterialCategory.METAL, state: MaterialState.SOLID,
    density: 19320, hardness: 2.5, brittleness: 0.05, elasticity: 0.45, friction: 0.40,
    meltingPoint: 1064, boilingPoint: 2856, thermalConductivity: 318,
    baseColor: [1.0, 0.84, 0.0], roughness: 0.15, metallic: 1.0, transparency: 0, reflectivity: 0.95,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: false, canDeform: true, canMelt: true, canBurn: false, soundType: 'metal_soft'
  },
  {
    id: 5, name: 'Титан', category: MaterialCategory.METAL, state: MaterialState.SOLID,
    density: 4506, hardness: 6.0, brittleness: 0.25, elasticity: 0.15, friction: 0.78,
    meltingPoint: 1668, boilingPoint: 3287, thermalConductivity: 21.9,
    baseColor: [0.76, 0.73, 0.69], roughness: 0.35, metallic: 1.0, transparency: 0, reflectivity: 0.65,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: false, canDeform: true, canMelt: true, canBurn: true, soundType: 'metal_hard'
  },
  {
    id: 6, name: 'Серебро', category: MaterialCategory.METAL, state: MaterialState.SOLID,
    density: 10490, hardness: 2.7, brittleness: 0.1, elasticity: 0.4, friction: 0.45,
    meltingPoint: 962, boilingPoint: 2162, thermalConductivity: 429,
    baseColor: [0.97, 0.97, 0.98], roughness: 0.1, metallic: 1.0, transparency: 0, reflectivity: 0.98,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: false, canDeform: true, canMelt: true, canBurn: false, soundType: 'metal_resonant'
  },
  // WOOD
  {
    id: 51, name: 'Дуб', category: MaterialCategory.WOOD, state: MaterialState.SOLID,
    density: 750, hardness: 4.0, brittleness: 0.6, elasticity: 0.1, friction: 0.45,
    meltingPoint: 9999, boilingPoint: 9999, thermalConductivity: 0.17,
    baseColor: [0.55, 0.42, 0.26], roughness: 0.85, metallic: 0, transparency: 0, reflectivity: 0.05,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: true, canDeform: false, canMelt: false, canBurn: true, soundType: 'wood_hard'
  },
  {
    id: 52, name: 'Сосна', category: MaterialCategory.WOOD, state: MaterialState.SOLID,
    density: 520, hardness: 2.5, brittleness: 0.7, elasticity: 0.15, friction: 0.42,
    meltingPoint: 9999, boilingPoint: 9999, thermalConductivity: 0.12,
    baseColor: [0.85, 0.72, 0.55], roughness: 0.80, metallic: 0, transparency: 0, reflectivity: 0.04,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: true, canDeform: false, canMelt: false, canBurn: true, soundType: 'wood_soft'
  },
  {
    id: 53, name: 'Бамбук', category: MaterialCategory.WOOD, state: MaterialState.SOLID,
    density: 400, hardness: 3.5, brittleness: 0.5, elasticity: 0.3, friction: 0.38,
    meltingPoint: 9999, boilingPoint: 9999, thermalConductivity: 0.15,
    baseColor: [0.78, 0.72, 0.45], roughness: 0.70, metallic: 0, transparency: 0, reflectivity: 0.06,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: true, canDeform: false, canMelt: false, canBurn: true, soundType: 'wood_hollow'
  },
  // GLASS
  {
    id: 81, name: 'Оконное стекло', category: MaterialCategory.GLASS, state: MaterialState.SOLID,
    density: 2500, hardness: 5.5, brittleness: 0.95, elasticity: 0, friction: 0.94,
    meltingPoint: 1400, boilingPoint: 2230, thermalConductivity: 1.05,
    baseColor: [0.95, 0.95, 0.95], roughness: 0.02, metallic: 0, transparency: 0.92, reflectivity: 0.04,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: true, canDeform: false, canMelt: true, canBurn: false, soundType: 'glass_shatter'
  },
  {
    id: 82, name: 'Закаленное стекло', category: MaterialCategory.GLASS, state: MaterialState.SOLID,
    density: 2500, hardness: 6.5, brittleness: 0.98, elasticity: 0, friction: 0.94,
    meltingPoint: 1400, boilingPoint: 2230, thermalConductivity: 1.05,
    baseColor: [0.96, 0.96, 0.96], roughness: 0.01, metallic: 0, transparency: 0.95, reflectivity: 0.04,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: true, canDeform: false, canMelt: true, canBurn: false, soundType: 'glass_hard'
  },
  // STONE
  {
    id: 101, name: 'Гранит', category: MaterialCategory.STONE, state: MaterialState.SOLID,
    density: 2750, hardness: 7.0, brittleness: 0.7, elasticity: 0, friction: 0.6,
    meltingPoint: 1260, boilingPoint: 2500, thermalConductivity: 2.9,
    baseColor: [0.65, 0.60, 0.58], roughness: 0.9, metallic: 0, transparency: 0, reflectivity: 0.03,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: true, canDeform: false, canMelt: true, canBurn: false, soundType: 'stone_hard'
  },
  {
    id: 102, name: 'Мрамор', category: MaterialCategory.STONE, state: MaterialState.SOLID,
    density: 2700, hardness: 3.5, brittleness: 0.6, elasticity: 0, friction: 0.55,
    meltingPoint: 1340, boilingPoint: 2500, thermalConductivity: 2.5,
    baseColor: [0.95, 0.93, 0.90], roughness: 0.3, metallic: 0, transparency: 0.05, reflectivity: 0.15,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: true, canDeform: false, canMelt: true, canBurn: false, soundType: 'stone_solid'
  },
  // LIQUIDS
  {
    id: 151, name: 'Вода', category: MaterialCategory.CHEMICAL, state: MaterialState.LIQUID,
    density: 1000, hardness: 0, brittleness: 0, elasticity: 0, friction: 0.01,
    meltingPoint: 0, boilingPoint: 100, thermalConductivity: 0.6,
    baseColor: [0.4, 0.6, 0.8], roughness: 0, metallic: 0, transparency: 0.85, reflectivity: 0.02,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: false, canDeform: true, canMelt: false, canBurn: false, soundType: 'water_splash'
  },
  {
    id: 152, name: 'Лава', category: MaterialCategory.CHEMICAL, state: MaterialState.LIQUID,
    density: 3100, hardness: 0, brittleness: 0, elasticity: 0, friction: 0.5,
    meltingPoint: 700, boilingPoint: 1200, thermalConductivity: 3.0,
    baseColor: [1.0, 0.3, 0.0], roughness: 0.6, metallic: 0, transparency: 0, reflectivity: 0.1,
    emissive: [1.0, 0.4, 0.0], emissiveStrength: 5.0,
    canShatter: false, canDeform: true, canMelt: false, canBurn: false, soundType: 'lava_bubble'
  },
  // PLASTIC
  {
    id: 181, name: 'Полиэтилен', category: MaterialCategory.PLASTIC, state: MaterialState.SOLID,
    density: 950, hardness: 2.0, brittleness: 0.4, elasticity: 0.5, friction: 0.2,
    meltingPoint: 130, boilingPoint: 9999, thermalConductivity: 0.4,
    baseColor: [0.9, 0.9, 0.9], roughness: 0.3, metallic: 0, transparency: 0.2, reflectivity: 0.04,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: true, canDeform: true, canMelt: true, canBurn: true, soundType: 'plastic_light'
  },
  {
    id: 182, name: 'Резина', category: MaterialCategory.PLASTIC, state: MaterialState.SOLID,
    density: 1100, hardness: 1.5, brittleness: 0.1, elasticity: 0.9, friction: 0.9,
    meltingPoint: 180, boilingPoint: 9999, thermalConductivity: 0.16,
    baseColor: [0.1, 0.1, 0.1], roughness: 0.7, metallic: 0, transparency: 0, reflectivity: 0.02,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: false, canDeform: true, canMelt: true, canBurn: true, soundType: 'rubber_bounce'
  },
  // GAS
  {
    id: 201, name: 'Пар', category: MaterialCategory.CHEMICAL, state: MaterialState.GAS,
    density: 0.598, hardness: 0, brittleness: 0, elasticity: 0, friction: 0,
    meltingPoint: 0, boilingPoint: 100, thermalConductivity: 0.016,
    baseColor: [0.9, 0.9, 0.95], roughness: 0, metallic: 0, transparency: 0.8, reflectivity: 0,
    emissive: [0, 0, 0], emissiveStrength: 0,
    canShatter: false, canDeform: true, canMelt: false, canBurn: false, soundType: 'steam_hiss'
  },
  {
    id: 202, name: 'Огонь', category: MaterialCategory.CHEMICAL, state: MaterialState.PLASMA,
    density: 0.3, hardness: 0, brittleness: 0, elasticity: 0, friction: 0,
    meltingPoint: 9999, boilingPoint: 9999, thermalConductivity: 0.05,
    baseColor: [1.0, 0.5, 0.0], roughness: 0, metallic: 0, transparency: 0.5, reflectivity: 0,
    emissive: [1.0, 0.6, 0.1], emissiveStrength: 8.0,
    canShatter: false, canDeform: true, canMelt: false, canBurn: false, soundType: 'fire_crackle'
  },
];

export function getMaterialsByCategory(category: MaterialCategory): MaterialProperties[] {
  return MATERIALS.filter(m => m.category === category);
}

export function getMaterialsByState(state: MaterialState): MaterialProperties[] {
  return MATERIALS.filter(m => m.state === state);
}

export function getMaterialById(id: number): MaterialProperties | undefined {
  return MATERIALS.find(m => m.id === id);
}
