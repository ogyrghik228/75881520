export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: [number, number, number];
  alpha: number;
  type: 'spark' | 'smoke' | 'fire' | 'water' | 'debris';
}

export class ParticleSystem {
  private particles: Particle[] = [];
  private maxParticles: number;
  private gravity: number = 300;
  
  constructor(maxParticles: number = 500) {
    this.maxParticles = maxParticles;
  }
  
  public emit(
    x: number,
    y: number,
    count: number,
    type: Particle['type'],
    spread: number = 100,
    baseVelocity: { x: number; y: number } = { x: 0, y: 0 }
  ): void {
    for (let i = 0; i < count && this.particles.length < this.maxParticles; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * spread;
      
      let particle: Particle;
      
      switch (type) {
        case 'spark':
          particle = {
            x, y,
            vx: baseVelocity.x + Math.cos(angle) * speed,
            vy: baseVelocity.y + Math.sin(angle) * speed - 100,
            life: 0.3 + Math.random() * 0.5,
            maxLife: 0.5,
            size: 2 + Math.random() * 3,
            color: [1, 0.8 + Math.random() * 0.2, 0.2 + Math.random() * 0.3],
            alpha: 1,
            type
          };
          break;
        case 'smoke':
          particle = {
            x: x + (Math.random() - 0.5) * 20,
            y,
            vx: (Math.random() - 0.5) * 30,
            vy: -50 - Math.random() * 50,
            life: 1 + Math.random() * 2,
            maxLife: 2,
            size: 10 + Math.random() * 20,
            color: [0.3, 0.3, 0.35],
            alpha: 0.5,
            type
          };
          break;
        case 'fire':
          particle = {
            x: x + (Math.random() - 0.5) * 10,
            y,
            vx: (Math.random() - 0.5) * 40,
            vy: -80 - Math.random() * 80,
            life: 0.3 + Math.random() * 0.5,
            maxLife: 0.6,
            size: 8 + Math.random() * 15,
            color: [1, 0.3 + Math.random() * 0.4, 0],
            alpha: 0.9,
            type
          };
          break;
        case 'water':
          particle = {
            x, y,
            vx: baseVelocity.x + Math.cos(angle) * speed * 0.5,
            vy: baseVelocity.y + Math.sin(angle) * speed * 0.5,
            life: 0.5 + Math.random() * 1,
            maxLife: 1,
            size: 3 + Math.random() * 5,
            color: [0.4, 0.6, 0.9],
            alpha: 0.7,
            type
          };
          break;
        case 'debris':
          particle = {
            x, y,
            vx: baseVelocity.x + Math.cos(angle) * speed,
            vy: baseVelocity.y + Math.sin(angle) * speed - 50,
            life: 1 + Math.random() * 2,
            maxLife: 2,
            size: 2 + Math.random() * 4,
            color: [0.5, 0.4, 0.3],
            alpha: 1,
            type
          };
          break;
      }
      
      this.particles.push(particle);
    }
  }
  
  public update(deltaTime: number): void {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      
      // Apply gravity (less for smoke/fire)
      if (p.type === 'smoke') {
        p.vy -= 50 * deltaTime; // Rise
      } else if (p.type === 'fire') {
        p.vy -= 100 * deltaTime; // Rise faster
      } else {
        p.vy += this.gravity * deltaTime;
      }
      
      // Update position
      p.x += p.vx * deltaTime;
      p.y += p.vy * deltaTime;
      
      // Update life
      p.life -= deltaTime;
      
      // Fade out
      const lifeRatio = p.life / p.maxLife;
      p.alpha = lifeRatio;
      
      // Grow smoke
      if (p.type === 'smoke') {
        p.size += 10 * deltaTime;
      }
      
      // Remove dead particles
      if (p.life <= 0) {
        this.particles.splice(i, 1);
      }
    }
  }
  
  public getParticles(): Particle[] {
    return this.particles;
  }
  
  public clear(): void {
    this.particles = [];
  }
  
  public setMaxParticles(max: number): void {
    this.maxParticles = max;
  }
}
