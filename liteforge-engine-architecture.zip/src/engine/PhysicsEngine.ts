import { MaterialProperties } from './MaterialDatabase';

export interface PhysicsBody {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  mass: number;
  material: MaterialProperties;
  rotation: number;
  angularVelocity: number;
  isStatic: boolean;
  temperature: number;
  health: number;
}

export interface Fragment {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  rotation: number;
  angularVelocity: number;
  lifetime: number;
  color: [number, number, number];
}

export class PhysicsWorld {
  private bodies: PhysicsBody[] = [];
  private fragments: Fragment[] = [];
  private gravity: number = 500;
  private bounds: { width: number; height: number };
  private nextId: number = 1;
  
  constructor(width: number, height: number) {
    this.bounds = { width, height };
  }
  
  public addBody(
    x: number,
    y: number,
    radius: number,
    material: MaterialProperties,
    isStatic: boolean = false
  ): PhysicsBody {
    const body: PhysicsBody = {
      id: this.nextId++,
      x,
      y,
      vx: 0,
      vy: 0,
      radius,
      mass: material.density * radius * radius * Math.PI,
      material,
      rotation: 0,
      angularVelocity: (Math.random() - 0.5) * 2,
      isStatic,
      temperature: 20,
      health: 100
    };
    this.bodies.push(body);
    return body;
  }
  
  public removeBody(id: number): void {
    this.bodies = this.bodies.filter(b => b.id !== id);
  }
  
  public applyForce(bodyId: number, fx: number, fy: number): void {
    const body = this.bodies.find(b => b.id === bodyId);
    if (body && !body.isStatic) {
      body.vx += fx / body.mass;
      body.vy += fy / body.mass;
    }
  }
  
  public applyImpact(bodyId: number, force: number): void {
    const body = this.bodies.find(b => b.id === bodyId);
    if (!body) return;
    
    const fractureThreshold = body.material.hardness * 1000 * (1 - body.material.brittleness);
    
    if (force > fractureThreshold && body.material.canShatter) {
      this.shatterBody(body);
    } else if (body.material.canDeform) {
      body.health -= force / 100;
      if (body.health <= 0) {
        this.removeBody(body.id);
      }
    }
  }
  
  private shatterBody(body: PhysicsBody): void {
    const fragmentCount = Math.floor(5 + body.material.brittleness * 10);
    
    for (let i = 0; i < fragmentCount; i++) {
      const angle = (Math.PI * 2 * i) / fragmentCount + Math.random() * 0.5;
      const speed = 100 + Math.random() * 200;
      
      this.fragments.push({
        id: this.nextId++,
        x: body.x + Math.cos(angle) * body.radius * 0.5,
        y: body.y + Math.sin(angle) * body.radius * 0.5,
        vx: body.vx + Math.cos(angle) * speed,
        vy: body.vy + Math.sin(angle) * speed,
        radius: body.radius * (0.1 + Math.random() * 0.2),
        rotation: Math.random() * Math.PI * 2,
        angularVelocity: (Math.random() - 0.5) * 20,
        lifetime: 2 + Math.random() * 2,
        color: body.material.baseColor
      });
    }
    
    this.removeBody(body.id);
  }
  
  public update(deltaTime: number): void {
    // Update bodies
    for (const body of this.bodies) {
      if (body.isStatic) continue;
      
      // Apply gravity
      body.vy += this.gravity * deltaTime;
      
      // Apply friction
      const friction = body.material.friction * 0.99;
      body.vx *= friction;
      
      // Update position
      body.x += body.vx * deltaTime;
      body.y += body.vy * deltaTime;
      body.rotation += body.angularVelocity * deltaTime;
      
      // Bounds collision
      if (body.y + body.radius > this.bounds.height) {
        body.y = this.bounds.height - body.radius;
        const impactForce = Math.abs(body.vy) * body.mass * 0.01;
        body.vy *= -body.material.elasticity;
        body.vx *= 0.9;
        
        if (impactForce > 50) {
          this.applyImpact(body.id, impactForce);
        }
      }
      
      if (body.x - body.radius < 0) {
        body.x = body.radius;
        body.vx *= -body.material.elasticity;
      }
      if (body.x + body.radius > this.bounds.width) {
        body.x = this.bounds.width - body.radius;
        body.vx *= -body.material.elasticity;
      }
      if (body.y - body.radius < 0) {
        body.y = body.radius;
        body.vy *= -body.material.elasticity;
      }
    }
    
    // Body-to-body collisions
    for (let i = 0; i < this.bodies.length; i++) {
      for (let j = i + 1; j < this.bodies.length; j++) {
        this.resolveCollision(this.bodies[i], this.bodies[j]);
      }
    }
    
    // Update fragments
    for (let i = this.fragments.length - 1; i >= 0; i--) {
      const frag = this.fragments[i];
      frag.vy += this.gravity * deltaTime;
      frag.x += frag.vx * deltaTime;
      frag.y += frag.vy * deltaTime;
      frag.rotation += frag.angularVelocity * deltaTime;
      frag.lifetime -= deltaTime;
      
      if (frag.lifetime <= 0 || frag.y > this.bounds.height + 50) {
        this.fragments.splice(i, 1);
      }
    }
  }
  
  private resolveCollision(a: PhysicsBody, b: PhysicsBody): void {
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const minDist = a.radius + b.radius;
    
    if (distance < minDist && distance > 0) {
      const nx = dx / distance;
      const ny = dy / distance;
      const overlap = minDist - distance;
      
      // Separate bodies
      const totalMass = a.mass + b.mass;
      if (!a.isStatic) {
        a.x -= nx * overlap * (b.mass / totalMass);
        a.y -= ny * overlap * (b.mass / totalMass);
      }
      if (!b.isStatic) {
        b.x += nx * overlap * (a.mass / totalMass);
        b.y += ny * overlap * (a.mass / totalMass);
      }
      
      // Calculate relative velocity
      const dvx = a.vx - b.vx;
      const dvy = a.vy - b.vy;
      const dvn = dvx * nx + dvy * ny;
      
      if (dvn > 0) return;
      
      // Calculate impulse
      const restitution = Math.min(a.material.elasticity, b.material.elasticity);
      const impulse = (-(1 + restitution) * dvn) / (1/a.mass + 1/b.mass);
      
      // Apply impulse
      if (!a.isStatic) {
        a.vx += impulse * nx / a.mass;
        a.vy += impulse * ny / a.mass;
      }
      if (!b.isStatic) {
        b.vx -= impulse * nx / b.mass;
        b.vy -= impulse * ny / b.mass;
      }
      
      // Impact damage
      const impactForce = Math.abs(dvn) * 0.1;
      if (impactForce > 30) {
        this.applyImpact(a.id, impactForce);
        this.applyImpact(b.id, impactForce);
      }
    }
  }
  
  public getBodies(): PhysicsBody[] {
    return this.bodies;
  }
  
  public getFragments(): Fragment[] {
    return this.fragments;
  }
  
  public clear(): void {
    this.bodies = [];
    this.fragments = [];
  }
  
  public setBounds(width: number, height: number): void {
    this.bounds = { width, height };
  }
}
