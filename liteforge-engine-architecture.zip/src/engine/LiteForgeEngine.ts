import { PhysicsWorld, PhysicsBody, Fragment } from './PhysicsEngine';
import { ParticleSystem, Particle } from './ParticleSystem';
import { MaterialProperties, MaterialState } from './MaterialDatabase';

export type DeviceTier = 'low' | 'medium' | 'high';

export interface GraphicsSettings {
  shadowQuality: 'none' | 'low' | 'medium' | 'high';
  particleCount: number;
  antialiasing: boolean;
  postProcessing: boolean;
}

export interface EngineStats {
  fps: number;
  bodies: number;
  particles: number;
  fragments: number;
  deviceTier: DeviceTier;
}

export class LiteForgeEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private physics: PhysicsWorld;
  private particles: ParticleSystem;
  private running: boolean = false;
  private lastTime: number = 0;
  private frameCount: number = 0;
  private fpsTime: number = 0;
  private currentFps: number = 60;
  private deviceTier: DeviceTier;
  private settings: GraphicsSettings;
  private animationId: number | null = null;
  
  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) {
      throw new Error('Canvas 2D context not supported');
    }
    this.ctx = context;
    this.physics = new PhysicsWorld(canvas.width || 800, canvas.height || 600);
    this.deviceTier = this.detectDeviceTier();
    this.settings = this.getSettingsForTier(this.deviceTier);
    this.particles = new ParticleSystem(this.settings.particleCount);
    
    console.log(`🎮 LiteForge Engine инициализирован`);
    console.log(`📱 Уровень устройства: ${this.deviceTier}`);
  }
  
  private detectDeviceTier(): DeviceTier {
    const isMobile = /mobile|android|iphone|ipad/i.test(navigator.userAgent);
    const memory = (performance as any).memory?.jsHeapSizeLimit || 0;
    const cores = navigator.hardwareConcurrency || 2;
    
    if (isMobile || cores <= 2 || memory < 500000000) {
      return 'low';
    } else if (cores <= 4 || memory < 2000000000) {
      return 'medium';
    }
    return 'high';
  }
  
  private getSettingsForTier(tier: DeviceTier): GraphicsSettings {
    const presets = {
      low: {
        shadowQuality: 'none' as const,
        particleCount: 100,
        antialiasing: false,
        postProcessing: false
      },
      medium: {
        shadowQuality: 'low' as const,
        particleCount: 300,
        antialiasing: true,
        postProcessing: false
      },
      high: {
        shadowQuality: 'high' as const,
        particleCount: 500,
        antialiasing: true,
        postProcessing: true
      }
    };
    return presets[tier];
  }
  
  public start(): void {
    if (this.running) return;
    this.running = true;
    this.lastTime = performance.now();
    this.fpsTime = this.lastTime;
    this.gameLoop();
  }
  
  public stop(): void {
    this.running = false;
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
  }
  
  private gameLoop = (): void => {
    if (!this.running) return;
    
    const currentTime = performance.now();
    const deltaTime = Math.min((currentTime - this.lastTime) / 1000, 0.05);
    this.lastTime = currentTime;
    
    // FPS calculation
    this.frameCount++;
    if (currentTime - this.fpsTime >= 1000) {
      this.currentFps = this.frameCount;
      this.frameCount = 0;
      this.fpsTime = currentTime;
      
      // Adaptive quality
      this.adjustQuality();
    }
    
    this.update(deltaTime);
    this.render();
    
    this.animationId = requestAnimationFrame(this.gameLoop);
  };
  
  private adjustQuality(): void {
    if (this.currentFps < 30 && this.settings.particleCount > 50) {
      this.settings.particleCount = Math.floor(this.settings.particleCount * 0.8);
      this.particles.setMaxParticles(this.settings.particleCount);
      console.log('⚠️ Качество снижено для поддержания FPS');
    }
  }
  
  private update(deltaTime: number): void {
    this.physics.update(deltaTime);
    this.particles.update(deltaTime);
    
    // Emit particles for special materials
    for (const body of this.physics.getBodies()) {
      if (body.material.emissiveStrength > 0) {
        if (body.material.state === MaterialState.LIQUID) {
          // Lava bubbles
          if (Math.random() < 0.1) {
            this.particles.emit(
              body.x + (Math.random() - 0.5) * body.radius,
              body.y - body.radius,
              2,
              'fire',
              30
            );
          }
        } else if (body.material.state === MaterialState.PLASMA) {
          // Fire
          this.particles.emit(
            body.x,
            body.y - body.radius,
            3,
            'fire',
            20
          );
          if (Math.random() < 0.3) {
            this.particles.emit(body.x, body.y - body.radius * 1.5, 1, 'smoke', 15);
          }
        }
      }
    }
  }
  
  private render(): void {
    const ctx = this.ctx;
    const width = this.canvas.width;
    const height = this.canvas.height;
    
    // Clear with gradient background
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#1a1a2e');
    gradient.addColorStop(1, '#16213e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    // Draw grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    const gridSize = 50;
    for (let x = 0; x < width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
    
    // Draw fragments
    for (const frag of this.physics.getFragments()) {
      this.renderFragment(ctx, frag);
    }
    
    // Draw particles (behind bodies)
    for (const particle of this.particles.getParticles()) {
      this.renderParticle(ctx, particle);
    }
    
    // Draw bodies
    for (const body of this.physics.getBodies()) {
      this.renderBody(ctx, body);
    }
    
    // Draw ground
    ctx.fillStyle = '#0f0f1a';
    ctx.fillRect(0, height - 5, width, 5);
  }
  
  private renderBody(ctx: CanvasRenderingContext2D, body: PhysicsBody): void {
    const { x, y, radius, rotation, material } = body;
    
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rotation);
    
    // Shadow
    if (this.settings.shadowQuality !== 'none') {
      ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
      ctx.shadowBlur = 10;
      ctx.shadowOffsetX = 5;
      ctx.shadowOffsetY = 5;
    }
    
    // Main body
    const color = material.baseColor;
    
    // Create gradient for 3D effect
    const grad = ctx.createRadialGradient(
      -radius * 0.3, -radius * 0.3, 0,
      0, 0, radius
    );
    
    if (material.metallic > 0.5) {
      // Metallic material
      grad.addColorStop(0, `rgba(${color[0]*255 + 80}, ${color[1]*255 + 80}, ${color[2]*255 + 80}, 1)`);
      grad.addColorStop(0.5, `rgba(${color[0]*255}, ${color[1]*255}, ${color[2]*255}, 1)`);
      grad.addColorStop(1, `rgba(${color[0]*255 * 0.5}, ${color[1]*255 * 0.5}, ${color[2]*255 * 0.5}, 1)`);
    } else if (material.transparency > 0.5) {
      // Transparent material (glass, water)
      grad.addColorStop(0, `rgba(255, 255, 255, ${0.3 * (1 - material.transparency)})`);
      grad.addColorStop(0.5, `rgba(${color[0]*255}, ${color[1]*255}, ${color[2]*255}, ${0.5})`);
      grad.addColorStop(1, `rgba(${color[0]*255}, ${color[1]*255}, ${color[2]*255}, ${0.3})`);
    } else {
      // Regular material
      grad.addColorStop(0, `rgba(${Math.min(255, color[0]*255 + 40)}, ${Math.min(255, color[1]*255 + 40)}, ${Math.min(255, color[2]*255 + 40)}, 1)`);
      grad.addColorStop(1, `rgba(${color[0]*255 * 0.7}, ${color[1]*255 * 0.7}, ${color[2]*255 * 0.7}, 1)`);
    }
    
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fill();
    
    // Emissive glow
    if (material.emissiveStrength > 0) {
      ctx.shadowColor = `rgba(${material.emissive[0]*255}, ${material.emissive[1]*255}, ${material.emissive[2]*255}, 1)`;
      ctx.shadowBlur = radius * material.emissiveStrength;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
      
      ctx.fillStyle = `rgba(${material.emissive[0]*255}, ${material.emissive[1]*255}, ${material.emissive[2]*255}, 0.5)`;
      ctx.beginPath();
      ctx.arc(0, 0, radius, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Highlight
    ctx.fillStyle = `rgba(255, 255, 255, ${0.3 * material.reflectivity})`;
    ctx.beginPath();
    ctx.arc(-radius * 0.3, -radius * 0.3, radius * 0.3, 0, Math.PI * 2);
    ctx.fill();
    
    // Direction indicator for rotation
    ctx.strokeStyle = `rgba(255, 255, 255, 0.3)`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(radius * 0.6, 0);
    ctx.stroke();
    
    ctx.restore();
  }
  
  private renderFragment(ctx: CanvasRenderingContext2D, frag: Fragment): void {
    ctx.save();
    ctx.translate(frag.x, frag.y);
    ctx.rotate(frag.rotation);
    
    const alpha = Math.min(1, frag.lifetime);
    ctx.fillStyle = `rgba(${frag.color[0]*255}, ${frag.color[1]*255}, ${frag.color[2]*255}, ${alpha})`;
    
    // Draw irregular polygon
    ctx.beginPath();
    const sides = 5 + Math.floor(frag.radius);
    for (let i = 0; i < sides; i++) {
      const angle = (Math.PI * 2 * i) / sides;
      const r = frag.radius * (0.7 + Math.sin(i * 1.5) * 0.3);
      const px = Math.cos(angle) * r;
      const py = Math.sin(angle) * r;
      if (i === 0) {
        ctx.moveTo(px, py);
      } else {
        ctx.lineTo(px, py);
      }
    }
    ctx.closePath();
    ctx.fill();
    
    ctx.restore();
  }
  
  private renderParticle(ctx: CanvasRenderingContext2D, p: Particle): void {
    ctx.save();
    
    if (p.type === 'smoke') {
      ctx.fillStyle = `rgba(${p.color[0]*255}, ${p.color[1]*255}, ${p.color[2]*255}, ${p.alpha * 0.3})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    } else if (p.type === 'fire') {
      const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size);
      grad.addColorStop(0, `rgba(255, 255, 200, ${p.alpha})`);
      grad.addColorStop(0.3, `rgba(255, ${150 + Math.random()*50}, 0, ${p.alpha})`);
      grad.addColorStop(1, `rgba(255, 50, 0, 0)`);
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    } else if (p.type === 'spark') {
      ctx.fillStyle = `rgba(${p.color[0]*255}, ${p.color[1]*255}, ${p.color[2]*255}, ${p.alpha})`;
      ctx.shadowColor = `rgba(${p.color[0]*255}, ${p.color[1]*255}, ${p.color[2]*255}, 1)`;
      ctx.shadowBlur = 5;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = `rgba(${p.color[0]*255}, ${p.color[1]*255}, ${p.color[2]*255}, ${p.alpha})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
    
    ctx.restore();
  }
  
  // Public API
  public addBody(x: number, y: number, radius: number, material: MaterialProperties, isStatic: boolean = false): PhysicsBody {
    return this.physics.addBody(x, y, radius, material, isStatic);
  }
  
  public removeBody(id: number): void {
    this.physics.removeBody(id);
  }
  
  public applyForce(bodyId: number, fx: number, fy: number): void {
    this.physics.applyForce(bodyId, fx, fy);
  }
  
  public emitParticles(x: number, y: number, count: number, type: Particle['type']): void {
    this.particles.emit(x, y, count, type);
  }
  
  public clear(): void {
    this.physics.clear();
    this.particles.clear();
  }
  
  public resize(width: number, height: number): void {
    this.canvas.width = width;
    this.canvas.height = height;
    this.physics.setBounds(width, height);
  }
  
  public getStats(): EngineStats {
    return {
      fps: this.currentFps,
      bodies: this.physics.getBodies().length,
      particles: this.particles.getParticles().length,
      fragments: this.physics.getFragments().length,
      deviceTier: this.deviceTier
    };
  }
  
  public getDeviceTier(): DeviceTier {
    return this.deviceTier;
  }
  
  public getSettings(): GraphicsSettings {
    return this.settings;
  }
}
